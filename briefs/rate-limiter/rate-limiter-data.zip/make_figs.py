"""Figures for KPA brief Rate Limiter, drawn with kpa_chart at printed size. Data: data/ (see analysis.py)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kpa_chart import *
import pandas as pd, numpy as np
D = os.path.join(HERE, "data")
rd = lambda f: pd.read_csv(os.path.join(D, f), comment="#")
CPI = 321.943 / 255.657 - 1

# Figure 1: sales growth vs residential price change, 2019-25, vertically integrated IOUs
v = rd("kpa_fig1_sales_vs_price.csv")
fig, ax = plt.subplots(figsize=(FULL, 2.2), dpi=300)
ax.yaxis.grid(True, color=GRID, linewidth=0.5); ax.set_axisbelow(True); ax.tick_params(length=0, pad=3)
for s_ in ("top", "right", "left"): ax.spines[s_].set_visible(False)
ax.spines["bottom"].set_color(ZERO)
NAMED = {(19876, "VA"): ("Dominion Energy Virginia", (7, 5)), (7140, "GA"): ("Georgia Power", (-7, 5)),
         (11241, "LA"): ("Entergy Louisiana", (7, 4)), (803, "AZ"): ("APS (Pinnacle West)", (7, -7)),
         (9324, "IN"): ("Indiana Michigan Power (AEP)", (-7, -10))}
ctx = v[~v.apply(lambda r: (r.util, r.state) in NAMED, axis=1)]
ax.scatter(ctx.ds * 100, ctx.dp * 100, s=14, color=CONTEXT, alpha=0.75, linewidths=0, zorder=3)
for (u, st), (name, off) in NAMED.items():
    r = v[(v.util == u) & (v.state == st)].iloc[0]
    ax.scatter([r.ds * 100], [r.dp * 100], s=26, color=FOCUS, zorder=4, linewidths=0)
    ax.annotate(name, (r.ds * 100, r.dp * 100), xytext=off, textcoords="offset points", fontsize=7, color=FOCUS, fontweight="bold",
                ha="right" if off[0] < 0 else "left", va="center", zorder=5,
                bbox=dict(boxstyle="square,pad=0.1", fc="white", ec="none", alpha=0.85))
ax.axhline(CPI * 100, color=COMPARE, lw=1.0, ls=(0, (4, 2)), zorder=2)
label(ax, 59, CPI * 100 - 1.5, f"Consumer prices, +{CPI:.0%}", color=COMPARE, fontsize=7, ha="right", va="top")
ax.axvline(0, color=ZERO, lw=0.8, zorder=2)
ax.set_xlim(-20, 60); ax.set_ylim(-5, 75)
ax.set_xticks(range(-20, 61, 10)); ax.set_xticklabels([f"{t:+d}%" if t else "0" for t in range(-20, 61, 10)])
ax.set_yticks(range(0, 76, 25)); ax.set_yticklabels([f"+{t}%" if t else "0" for t in range(0, 76, 25)])
ax.set_xlabel("Change in retail sales, 2019–25", fontsize=7, color=MUTED)
ax.set_ylabel("Residential price change", fontsize=7, color=MUTED)
save(fig, "fig1.png")

# Figure 2: rate base growth vs EPS growth guidance
g = rd("kpa_fig2_guidance.csv").set_index("group")
order = ["Southern", "AEP", "Pinnacle West", "Dominion", "Entergy"]
fig, ax = plt.subplots(figsize=(FULL, 2.05), dpi=300)
ax.xaxis.grid(True, color=GRID, linewidth=0.5); ax.set_axisbelow(True); ax.tick_params(length=0, pad=3)
for s_ in ("top", "right", "bottom"): ax.spines[s_].set_visible(False)
ax.spines["left"].set_color(ZERO)
y = np.arange(len(order))[::-1].astype(float); h = 0.36
rb = g.loc[order, "rb_mid"].values; ep = g.loc[order, "eps_mid"].values; cv = g.loc[order, "conversion"].values
ax.barh(y + h / 2, rb, height=h, color=COMPARE, zorder=3)
ax.barh(y - h / 2, ep, height=h, color=FOCUS, zorder=3)
for yy, a, b, c in zip(y, rb, ep, cv):
    ax.text(a + 0.3, yy + h / 2, f"{a:.0f}%" if a == int(a) else f"{a:.1f}%", va="center", fontsize=7, color=COMPARE, fontweight="bold")
    ax.text(b + 0.3, yy - h / 2, f"{b:g}%  ({c:.0%})", va="center", fontsize=7, color=FOCUS, fontweight="bold")
ax.set_yticks(y); ax.set_yticklabels(order, fontsize=7.5)
ax.set_xlim(0, 20); ax.set_xticks([0, 5, 10, 15, 20]); ax.set_xticklabels(["0", "5%", "10%", "15%", "20%"])
ax.set_ylim(-0.7, len(order) + 0.4)
label(ax, 0, len(order) + 0.1, "Rate base growth", color=COMPARE, fontsize=7.5, va="center")
label(ax, 4.6, len(order) + 0.1, "EPS growth (share of rate base growth in brackets)", color=FOCUS, fontsize=7.5, va="center")
save(fig, "fig2.png")

# Figure 3: capital each MWh must carry, five-year change implied by guidance
order3 = ["Southern", "Entergy", "Pinnacle West"]
vals = g.loc[order3, "capital_per_mwh_5yr"].values * 100
fig, ax = plt.subplots(figsize=(FULL, 1.35), dpi=300)
ax.xaxis.grid(True, color=GRID, linewidth=0.5); ax.set_axisbelow(True); ax.tick_params(length=0, pad=3)
for s_ in ("top", "right", "bottom", "left"): ax.spines[s_].set_visible(False)
ys = np.arange(len(order3))[::-1].astype(float)
cols = [FOCUS if x > 0 else COMPARE for x in vals]
ax.barh(ys, vals, height=0.55, color=cols, zorder=3)
ax.axvline(0, color=ZERO, lw=0.8, zorder=4)
for y_, v_ in zip(ys, vals):
    ax.text(v_ + (0.8 if v_ > 0 else -0.8), y_, f"{v_:+.0f}%".replace("-", "\u2212"), va="center", ha="left" if v_ > 0 else "right", fontsize=8, fontweight="bold", color=FOCUS if v_ > 0 else COMPARE)
ax.set_yticks(ys); ax.set_yticklabels(order3, fontsize=7.5)
ax.set_xlim(-10, 45); ax.set_xticks([0, 10, 20, 30, 40]); ax.set_xticklabels(["0", "+10%", "+20%", "+30%", "+40%"])
save(fig, "fig3.png")
print("figs ok")
