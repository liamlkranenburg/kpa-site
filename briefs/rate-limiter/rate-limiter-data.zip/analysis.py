"""Rate Limiter (KPA): every KPA number in the brief is computed here.
Data: data/eia861_iou_2019_2025.csv (EIA-861 final 2019 and 2025), data/guidance.csv (company guidance, sourced in notes/facts.md),
data/eia861m_dominion_va_2025_2026.csv (EIA-861M monthly, Dominion Energy Virginia residential, 2025 final and January-September 2026 preliminary).
Run: python3 analysis.py  -> prints results and writes data/kpa_*.csv"""
import os, numpy as np, pandas as pd
import statsmodels.api as sm
HERE = os.path.dirname(os.path.abspath(__file__)); D = os.path.join(HERE, "data")
TAG = "Kranenburg Power Advisors, Rate Limiter v1.1"
def out(df, name, head):
    with open(os.path.join(D, name), "w", encoding="utf-8", newline="") as f:
        f.write(f"# {head}. {TAG}\n"); df.to_csv(f, index=False)

e = pd.read_csv(os.path.join(D, "eia861_iou_2019_2025.csv"), sep="|", comment="#")
e["p19"] = e.resRev19 / e.resMWh19 * 100      # cents per kWh (thousand $ / MWh x 100)
e["p25"] = e.resRev25 / e.resMWh25 * 100
e["dp"] = e.p25 / e.p19 - 1                    # residential price change 2019-25
e["ds"] = e.totMWh25 / e.totMWh19 - 1          # retail sales change 2019-25 (all customers, all service types)
CHOICE = {"OH", "PA", "NJ", "MD", "DE", "DC", "IL", "NY", "CT", "MA", "ME", "NH", "RI", "CA"}   # retail choice or CCA-heavy: bundled residential price not comparable
CPI19, CPI25 = 255.657, 321.943               # BLS CPI-U; 2025 = average of 11 months (October 2025 not published)
cpi = CPI25 / CPI19 - 1

# 1. Across vertically integrated investor-owned utilities: did sales growth hold residential prices down?
v = e[~e.state.isin(CHOICE)].copy()
w = v.resMWh25
X = sm.add_constant(v.ds)
wls = sm.WLS(v.dp, X, weights=w).fit(); ols = sm.OLS(v.dp, X).fit()
print(f"[1] units={len(v)}  weighted mean residential price change 2019-25 = {np.average(v.dp, weights=w):.3f}  CPI = {cpi:.3f}")
print(f"    WLS slope {wls.params.ds:.3f} (p={wls.pvalues.ds:.2f}, R2={wls.rsquared:.3f}); OLS slope {ols.params.ds:.3f} (p={ols.pvalues.ds:.2f})")
v["band"] = pd.cut(v.ds, [-1, 0, 0.10, 5], labels=["Sales fell", "Sales rose 0-10%", "Sales rose >10%"])
g = v.groupby("band", observed=True).apply(lambda x: pd.Series({"units": len(x), "sales_change": np.average(x.ds, weights=x.resMWh25),
                                                                 "res_price_change": np.average(x.dp, weights=x.resMWh25)}), include_groups=False)
print(g.round(3).to_string())
above = (v.dp > cpi).mean(); print(f"    share of units with residential price rise above CPI: {above:.2f}")
fast = v[v.ds > 0.10]; print(f"    fast-growth units above CPI: {(fast.dp > cpi).mean():.2f} of {len(fast)}")
out(v[["util", "state", "name", "totMWh19", "totMWh25", "ds", "p19", "p25", "dp", "resMWh25"]].round(4), "kpa_fig1_sales_vs_price.csv",
    "Figure 1: retail sales change and bundled residential price change, 2019-2025, vertically integrated investor-owned utilities by state (EIA-861)")

# 2. The five utility groups: 2019-25 sales and residential price (EIA-861)
GROUPS = {"Dominion": [(19876, "VA"), (19876, "NC"), (17539, "SC")],
          "Southern": [(195, "AL"), (7140, "GA"), (12686, "MS")],
          "AEP": [(733, "VA"), (733, "WV"), (9324, "IN"), (9324, "MI"), (10331, "TN"), (20521, "WV"), (22053, "KY"), (14006, "OH"), (15474, "OK"),
                  (17698, "AR"), (17698, "LA"), (17698, "TX")],
          "Entergy": [(814, "AR"), (11241, "LA"), (12685, "MS"), (13478, "LA"), (55937, "TX")],
          "Pinnacle West": [(803, "AZ")]}
rows = []
for k, units in GROUPS.items():
    s = e[e.apply(lambda r: (r.util, r.state) in units, axis=1)]
    assert len(s) == len(units), (k, len(s))
    b = s[~s.state.isin(CHOICE)]
    rows.append({"group": k, "sales19_TWh": s.totMWh19.sum() / 1e6, "sales25_TWh": s.totMWh25.sum() / 1e6,
                 "sales_change": s.totMWh25.sum() / s.totMWh19.sum() - 1,
                 "com_change": s.comMWh25.sum() / s.comMWh19.sum() - 1,
                 "res_price19": b.resRev19.sum() / b.resMWh19.sum() * 100, "res_price25": b.resRev25.sum() / b.resMWh25.sum() * 100})
grp = pd.DataFrame(rows); grp["res_price_change"] = grp.res_price25 / grp.res_price19 - 1
grp["sales_cagr"] = (1 + grp.sales_change) ** (1 / 6) - 1
print("\n[2] Five groups, 2019-25 (EIA-861; AEP excludes AEP Texas wires; prices exclude Ohio)"); print(grp.round(3).to_string())
for u, st, lab in [(19876, "VA", "Dominion Energy Virginia"), (7140, "GA", "Georgia Power"), (11241, "LA", "Entergy Louisiana"), (803, "AZ", "APS"), (14006, "OH", "AEP Ohio")]:
    r = e[(e.util == u) & (e.state == st)].iloc[0]
    print(f"    {lab}: sales {r.ds:+.3f}, commercial {r.comMWh25 / r.comMWh19 - 1:+.3f}, residential price {r.dp:+.3f} ({r.p19:.2f} -> {r.p25:.2f} c/kWh)")

# 3. Guidance: how much rate base growth reaches EPS, and how fast capital per MWh sold rises
gd = pd.read_csv(os.path.join(D, "guidance.csv"), comment="#")
gd["rb_mid"] = (gd.rb_lo + gd.rb_hi) / 2; gd["eps_mid"] = (gd.eps_lo + gd.eps_hi) / 2
gd["conversion"] = gd.eps_mid / gd.rb_mid
gd["sales_mid"] = (gd.sales_lo + gd.sales_hi) / 2
gd["capital_per_mwh_growth"] = (1 + gd.rb_mid / 100) / (1 + gd.sales_mid / 100) - 1
gd["capital_per_mwh_5yr"] = (1 + gd.capital_per_mwh_growth) ** 5 - 1
print("\n[3] Guidance"); print(gd[["group", "rb_mid", "eps_mid", "conversion", "sales_mid", "capital_per_mwh_growth", "capital_per_mwh_5yr"]].round(3).to_string())
out(gd.round(4), "kpa_fig2_guidance.csv", "Figure 2 and scorecard: company guidance for rate base, EPS and sales growth; KPA conversion (EPS growth / rate base growth) and capital per MWh growth")
out(grp.round(4), "kpa_groups_2019_2025.csv", "Five utility groups: retail sales and bundled residential price, 2019 and 2025 (EIA-861)")

# Entergy and AEP rate base CAGR from stated levels
print(f"\n    Entergy RB 46->97 (2025-30): {(97/46)**(1/5)-1:.3f}/yr; AEP RB 87->162 (2026-31): {(162/87)**(1/5)-1:.3f}/yr")
# Entergy capital per MWh: $46B / 128 TWh (2025) vs $97B / (128 x 1.09^5)
c25 = 46e9 / 128e6; c30 = 97e9 / (128e6 * 1.09 ** 5); print(f"    Entergy rate base per MWh: ${c25:.0f} (2025) -> ${c30:.0f} (2030E), {c30 / c25 - 1:+.3f}")
# Dominion Virginia bill (SCC order, 25 Nov 2025, via Cardinal News): +$11.24 in 2026 and +$2.36 in 2027 on a $149.92 bill for 1,000 kWh
print(f"    Dominion Virginia SCC order: +$13.60 on $149.92 = {13.60 / 149.92:.3f} over two years; 2026 step +$11.24 = {11.24 / 149.92:.3f}")

# 4. Dominion Energy Virginia residential revenue per kWh, January-September 2026 vs January-September 2025 (EIA-861M; 2026 preliminary)
m = pd.read_csv(os.path.join(D, "eia861m_dominion_va_2025_2026.csv"), comment="#")
mo26 = set(m[m.year == 2026].month); a = m[(m.year == 2025) & m.month.isin(mo26)]; b = m[m.year == 2026]
pa, pb = a.resRev.sum() / a.resMWh.sum() * 100, b.resRev.sum() / b.resMWh.sum() * 100
full25 = m[m.year == 2025]; pf = full25.resRev.sum() / full25.resMWh.sum() * 100
print(f"\n[4] Dominion Energy Virginia residential, months {min(mo26)}-{max(mo26)}: 2025 {pa:.2f} c/kWh -> 2026 {pb:.2f} c/kWh ({pb / pa - 1:+.3f}); full-year 2025 {pf:.2f} c/kWh")
