// Cold Storage (KPA): how the EIA data were read and analysed, run in a browser tab on https://www.eia.gov on 25 Nov 2026.
// Sources: EIA-930 six-month BALANCE files (https://www.eia.gov/electricity/gridmonitor/sixMonthFiles/EIA930_BALANCE_2025_Jan_Jun.csv,
//   ..._2025_Jul_Dec.csv, ..._2026_Jan_Jun.csv); EIA-860M October 2026 (https://www.eia.gov/electricity/data/eia860m/xls/october_generator2026.xlsx).
// Outputs: kpa_peak_shaving_results.csv, eia930_peak_windows.csv, battery_capacity_by_ba.csv. analysis.py re-checks ERCOT and CAISO from the windows.

// 1. EIA-930: per balancing authority (BA) and hour (local time at end of hour) keep demand (adjusted if present, else reported),
//    solar (with + without integrated storage), wind (with + without integrated storage) and "Net Generation (MW) from Battery Storage".
//    Net load = demand - solar - wind. Hours whose demand exceeds 1.3x both neighbours are dropped as spikes.
// 2. EIA-860M October 2026: every generator with energy source MWH (Operating and Retired sheets); a battery counts as in service in a
//    month if its operating year/month is on or before it and it had not retired. Power = nameplate MW; energy = nameplate MWh.
// 3. Peak-shaving limit (energy-limited), for a season series s and its peak net-load hour im, power P and energy E:
const shaveAt = (s, im, P, E) => {
  const pk = s[im];
  const need = R => { const th = pk - R; let e = 0;
    for (let i = im; i < s.length && s[i] > th; i++) e += s[i] - th;      // unbroken run of hours above the cut line
    for (let i = im - 1; i >= 0 && s[i] > th; i--) e += s[i] - th;
    return e; };
  if (need(P) <= E) return P;
  let lo = 0, hi = P; for (let k = 0; k < 40; k++) { const mid = (lo + hi) / 2; if (need(mid) <= E) lo = mid; else hi = mid; }
  return lo;   // the largest cut the fleet could hold, starting full, with perfect foresight and no recharge inside the run
};
// 4. Seasons: W25 = Jan-Feb 2025 (EIA-930 battery data begin 1 Jan 2025); S25 = Jun-Sep 2025; W26 = Dec 2025-Feb 2026.
//    For each BA and season: peak net-load hour; limit with the fleet in service that month (eff_mw) and with the October 2026 fleet
//    (oct26_eff_mw); the same limit at each of the five highest daily peaks (median and minimum share); observed battery output at the
//    peak hour and the mean over the 10 highest net-load hours.
// 5. BAs: ERCO (ERCOT), CISO (CAISO), AZPS (Arizona Public Service), SRP (Salt River Project), NEVP (NV Energy), PNM (Public Service Co. of
//    New Mexico): six large battery fleets in Texas and the West (44.4 GW, 78% of US battery capacity in EIA-860M, Oct 2026). Three other
//    BAs with batteries, FPL, PSCO and SOCO, were left out of the analysis because their EIA-930 battery output exceeded their EIA-860M
//    battery capacity. (Comment corrected in v1.1; the code and outputs are unchanged.)
